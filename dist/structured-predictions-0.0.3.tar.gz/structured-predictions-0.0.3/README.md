![Build Status](https://github.com/hi-paris/structured-predictions/workflows/pytesting/badge.svg)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Github All Releases](https://img.shields.io/github/downloads/hi-paris/structured-predictions/total.svg)]()

# structured-predictions

## IOKR + OK3 + DEEP-IOKR

### Hello World

![Screenshot Design Structured Prediction](images/architecture%20structured%20prediction.png)

